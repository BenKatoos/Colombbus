
Hello!


Thank you for downloading our fonts. 
This is demo, so all glyphys are not included.

If you want full glyphs, please buy at patriastd.com



Thank you