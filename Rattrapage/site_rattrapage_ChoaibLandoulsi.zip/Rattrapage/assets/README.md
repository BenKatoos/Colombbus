##### contenu texte: 

# navigation 
    MyUnicorn

        Le principe
        Nos licornes
        Nous trouver

# Titre page 
Un jour, une licorne

# Le principe

    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In dictum dapibus ante, eu aliquam ante euismod eleifend. Ut malesuada augue ut luctus pellentesque. Aenean id varius ipsum. Nunc malesuada ex ut ipsum interdum vestibulum. Integer facilisis finibus orci, sit amet pretium diam placerat vitae. Nunc auctor tincidunt mollis. Nullam quis turpis sed lorem elementum semper eget semper risus. In nec mauris aliquam, congue metus euismod, cursus leo. Vivamus laoreet commodo leo, ut cursus justo blandit in. Aenean pretium mi a auctor pulvinar. Mauris sodales sollicitudin sodales. Sed mollis sed lectus id facilisis. Quisque pharetra a purus eget porttitor. Proin rhoncus risus non mauris iaculis sodales. Pellentesque euismod dui erat, non sodales ipsum sollicitudin sed.

    Donec nisi eros, luctus id pretium eget, consequat elementum risus. Fusce eleifend lacinia orci eu iaculis. Vestibulum vestibulum justo quis commodo congue. Aliquam purus leo, dictum in nisl at, pellentesque bibendum mi. Nulla convallis mi eget nisl convallis dictum. Vestibulum a massa lacus. Aenean quis enim diam.


# Nos licornes

    Lulu Confetty - Lapillon Magik - El Ninjacorn - Sweety Candy


# Nous trouver

* Notre élevage de licornes est situé au :
    18, rue Geoffroy l'Asnier 
    75004 Paris 
    01 23 45 67 89

* Newsletter

    Abonnez-vous simplement à notre newsletter mensuelle !


###### Instruction 
# Polices par défaut : 
	font-family: Arial, sans-serif;

# Police des titres :
	font-family: 'Courgette', cursive;

# Etoiles dans les titres : 
    FontAwesome => fa-star
    
# Couleurs : 
	barre de menus : #C55394
	hover menu : #EB43A3
    titre  : #C55394 / #EB43A3
	footer : #E577B5
	noir : #333
	blanc : #FFF


# 
Rproduire les maquettes (desktop et mobile) de la page My Unicorn
une balise iframe à utiliser dans le HTML afin de d'insérer la maps avec l'adresse de l'ENSIIE

-> Desktop : animation sur les images au survol : l'image fait 1.5 de sa taille d'origine

-> Mobile : - taille des écrans inférieur à 576px 
            - pas d'animation sur les images

